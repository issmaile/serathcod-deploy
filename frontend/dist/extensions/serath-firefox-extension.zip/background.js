// Serath Sync — Background (Firefox, MV3 event page via background.scripts)
// Handles token push from content script. Background context is not subject
// to mixed-content blocking, so HTTP requests work even from HTTPS pages.

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'SERATH_PUSH_TOKEN') {
    const { token, serathUrl } = message;

    fetch(serathUrl, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ codinafrica_token: token })
    })
      .then(res => res.json())
      .then(data => {
        sendResponse({ success: data.success });
      })
      .catch(err => {
        sendResponse({ success: false, error: err.message });
      });

    return true; // Keep channel open for async
  }
});
