// Serath Sync Popup (Firefox) — manages URL, status display, and refresh

const DEFAULT_URL = 'http://100.119.113.41:4000/api/settings';

const urlInput = document.getElementById('serathUrl');
const statusRow = document.getElementById('statusRow');
const dot = document.getElementById('dot');
const statusText = document.getElementById('statusText');
const saveBtn = document.getElementById('saveBtn');
const refreshBtn = document.getElementById('refreshBtn');

// ── Load saved URL ──
chrome.storage.local.get(['serathUrl'], (result) => {
  urlInput.value = result.serathUrl || DEFAULT_URL;
});

// ── Save ──
saveBtn.addEventListener('click', () => {
  const url = urlInput.value.trim() || DEFAULT_URL;
  chrome.storage.local.set({ serathUrl: url }, () => {
    saveBtn.textContent = '✓ Saved!';
    saveBtn.style.color = '#10b981';
    saveBtn.style.borderColor = 'rgba(16, 185, 129, 0.4)';
    setTimeout(() => {
      saveBtn.textContent = '💾 Save';
      saveBtn.style.color = '#00f0ff';
      saveBtn.style.borderColor = 'rgba(0, 240, 255, 0.3)';
    }, 1500);
  });
});

// ── Refresh ──
refreshBtn.addEventListener('click', () => {
  setStatus('loading', 'Checking...', 'loading');

  // Ask the content script (running on manager.codinafrica.com) to push the token
  chrome.tabs.query({ url: '*://manager.codinafrica.com/*' }, (tabs) => {
    if (tabs.length === 0) {
      setStatus('disconnected', 'No manager.codinafrica.com tab open', 'red');
      return;
    }

    chrome.tabs.sendMessage(tabs[0].id, { type: 'SERATH_REFRESH' }, (response) => {
      if (chrome.runtime.lastError) {
        // Content script not loaded — might need page reload
        chrome.tabs.reload(tabs[0].id);
        setStatus('disconnected', 'Reloading tab...', 'red');
        return;
      }

      if (response && response.success) {
        setStatus('connected', 'Connected ✓', 'green');

        // Verify by checking the backend
        const baseUrl = urlInput.value.trim().replace('/api/settings', '');
        fetch(`${baseUrl}/api/serath/status`)
          .then(r => r.json())
          .then(data => {
            if (data.success && data.data.connected) {
              setStatus('connected', 'Backend reachable ✓', 'green');
            }
          })
          .catch(() => {});
      } else {
        setStatus('disconnected', 'No token found — log in first', 'red');
      }
    });
  });
});

// ── Helper ──
function setStatus(state, text, dotColor) {
  statusRow.className = 'status-row ' + (state === 'connected' ? 'connected' : 'disconnected');
  statusText.textContent = text;
  dot.className = 'dot';
  if (dotColor === 'green') dot.classList.add('green');
  else if (dotColor === 'red') dot.classList.add('red');
  else { dot.classList.add('red'); dot.style.opacity = '0.3'; dot.style.animation = 'pulse 1s infinite'; }
}
