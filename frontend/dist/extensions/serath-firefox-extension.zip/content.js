// Serath Auto-Token Sync — content script for manager.codinafrica.com (Firefox)
// Captures the CODINAFRICA auth token and pushes it to the Serath backend
// via the background context (bypasses mixed-content blocking).

// Default: agentbook over Tailscale (backend lives there, not on localhost).
// Override in the popup — stored in chrome.storage.local.
const DEFAULT_SERATH_URL = 'http://100.119.113.41:4000/api/settings';
const TOKEN_STORAGE_KEY = 'id_token'; // CODINAFRICA's localStorage JWT key
const POLL_INTERVAL_MS = 2000;

let lastToken = null;

function getSerathUrl() {
  return new Promise((resolve) => {
    if (typeof chrome !== 'undefined' && chrome.storage) {
      chrome.storage.local.get(['serathUrl'], (result) => {
        resolve(result.serathUrl || DEFAULT_SERATH_URL);
      });
    } else {
      resolve(DEFAULT_SERATH_URL);
    }
  });
}

function pushToken(token, serathUrl) {
  chrome.runtime.sendMessage({
    type: 'SERATH_PUSH_TOKEN',
    token: token,
    serathUrl: serathUrl
  }, (response) => {
    if (chrome.runtime.lastError) {
      console.error('[Serath Sync] Background error:', chrome.runtime.lastError.message);
      return;
    }
    if (response && response.success) {
      console.log('[Serath Sync] Successfully updated token in Serath!');
    } else {
      console.error('[Serath Sync] Failed:', (response && response.error) || 'unknown');
    }
  });
}

async function checkForToken() {
  const token = localStorage.getItem(TOKEN_STORAGE_KEY);

  if (token && token !== lastToken) {
    lastToken = token;
    const serathUrl = await getSerathUrl();
    console.log('[Serath Sync] Found new token, sending to backend...');
    pushToken(token, serathUrl);
  }
}

// Check on load
checkForToken();

// Check periodically since the site is an SPA and might set the token after login without a full reload
setInterval(checkForToken, POLL_INTERVAL_MS);

// ── Popup message listener ──
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'SERATH_REFRESH') {
    const token = localStorage.getItem(TOKEN_STORAGE_KEY);
    if (token) {
      getSerathUrl().then(serathUrl => {
        chrome.runtime.sendMessage({
          type: 'SERATH_PUSH_TOKEN',
          token: token,
          serathUrl: serathUrl
        }, (res) => {
          sendResponse({ success: res ? res.success : false });
        });
      });
    } else {
      sendResponse({ success: false, error: 'No token found — log in first' });
    }
    return true;
  }
});
