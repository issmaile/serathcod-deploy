// Serath Auto-Token Sync — content script for manager.codinafrica.com
// Captures the CODINAFRICA auth token and pushes it to the Serath backend
// via the background service worker (bypasses mixed-content blocking).
// serathUrl is stored as an ORIGIN; background.js appends /api/settings.

const DEFAULT_ORIGIN = 'https://serathcod-app.oxp95q.easypanel.host';
const AUTH_ERROR = 'token missing/expired — paste a new one from Settings';

let lastToken = null;
let lastPushResult = null; // true = success, false = failed, null = never attempted

function getSerathUrl() {
  return new Promise((resolve) => {
    if (typeof chrome !== 'undefined' && chrome.storage) {
      chrome.storage.local.get(['serathUrl'], (result) => {
        resolve(result.serathUrl || DEFAULT_ORIGIN);
      });
    } else {
      resolve(DEFAULT_ORIGIN);
    }
  });
}

function getSyncSettings() {
  return new Promise((resolve) => {
    chrome.storage.local.get(['apiToken', 'authError'], (result) => {
      resolve({
        apiToken: (result.apiToken || '').trim(),
        authError: result.authError || ''
      });
    });
  });
}

function pushToken(token, serathUrl) {
  chrome.runtime.sendMessage({
    type: 'SERATH_PUSH_TOKEN',
    token: token,
    serathUrl: serathUrl
  }, (response) => {
    if (chrome.runtime.lastError) {
      lastPushResult = false;
      console.error('[Serath Sync] Background worker error:', chrome.runtime.lastError.message);
      return;
    }
    if (response && response.success) {
      lastPushResult = true;
      console.log('[Serath Sync] Successfully updated token in Serath!');
    } else {
      lastPushResult = false;
      console.error('[Serath Sync] Failed:', (response && response.error) || 'unknown');
    }
  });
}

async function checkForToken() {
  const token = localStorage.getItem('id_token');
  const { apiToken, authError } = await getSyncSettings();

  if (!apiToken || authError) {
    lastToken = null;
    return;
  }

  if (token && token !== lastToken) {
    lastToken = token;
    const serathUrl = await getSerathUrl();
    console.log('[Serath Sync] Found new token, sending to backend...');
    pushToken(token, serathUrl);
  }
}

// Check on load
checkForToken();

// Check periodically since the site is an SPA and might set the token after login without a full reload
setInterval(checkForToken, 2000);

// ── Popup message listener ──
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'SERATH_STATUS') {
    const token = localStorage.getItem('id_token');
    getSyncSettings().then(({ apiToken, authError }) => {
      const noCreds = !apiToken || authError;
      sendResponse({
        hasToken: !!token,
        linked: !noCreds && !!token && lastPushResult === true,
        lastPushOK: lastPushResult,
        status: noCreds ? 401 : token ? 200 : 404
      });
    });
    return true;
  }

  if (message.type === 'SERATH_REFRESH') {
    const token = localStorage.getItem('id_token');
    getSyncSettings().then(({ apiToken, authError }) => {
      if (!apiToken || authError) {
        sendResponse({ success: false, error: AUTH_ERROR, status: 401 });
        return;
      }

      if (!token) {
        sendResponse({ success: false, error: 'No token found — log in first' });
        return;
      }

      getSerathUrl().then(serathUrl => {
        chrome.runtime.sendMessage({
          type: 'SERATH_PUSH_TOKEN',
          token: token,
          serathUrl: serathUrl
        }, (res) => {
          if (chrome.runtime.lastError) {
            sendResponse({ success: false, error: chrome.runtime.lastError.message });
            return;
          }
          // Track push result for SERATH_STATUS
          lastPushResult = !!(res && res.success);
          sendResponse(res || { success: false, error: 'Backend request failed' });
        });
      });
    });
    return true;
  }
});
