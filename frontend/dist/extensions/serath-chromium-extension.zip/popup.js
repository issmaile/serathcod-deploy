// Serath Sync Popup — connection status, URL management, CODINAFRICA push
// Normalizes URLs to origin; endpoints are derived (/api/settings, /api/auth/me, …).

const DEFAULT_ORIGIN = 'https://serathcod-app.oxp95q.easypanel.host';
const AUTH_ERROR = 'Not linked — paste your API token (Settings > API tokens in the app)';

const urlInput = document.getElementById('serathUrl');
const apiTokenInput = document.getElementById('apiToken');

// Connection status bar (top)
const connBar = document.getElementById('connBar');
const connDot = document.getElementById('connDot');
const connText = document.getElementById('connText');

// CODINAFRICA push status bar
const codBar = document.getElementById('codBar');
const codDot = document.getElementById('codDot');
const codText = document.getElementById('codText');

const saveBtn = document.getElementById('saveBtn');
const testBtn = document.getElementById('testBtn');
const refreshBtn = document.getElementById('refreshBtn');

// ── URL normalizer ──────────────────────────────────────────────────────────
// Accept bare host, host:port, or full /api/settings URL.
// Returns the ORIGIN only (protocol + host + port).
function normalizeUrl(input) {
  if (!input || !(input = input.trim())) return null;

  // Strip trailing /api/settings path if present
  input = input.replace(/\/api\/settings\/?$/, '');

  // Add https:// if no protocol present
  if (!/^https?:\/\//i.test(input)) {
    input = 'https://' + input;
  }

  try {
    return new URL(input).origin;
  } catch {
    return null;
  }
}

// ── Status-bar helpers ──────────────────────────────────────────────────────
function setBarStatus(bar, dot, textEl, type, text) {
  bar.className = 'status-row';
  textEl.textContent = text;
  dot.className = 'dot';
  dot.style.opacity = '';
  dot.style.animation = '';

  if (type === 'connected') {
    bar.classList.add('connected');
    dot.classList.add('green');
  } else if (type === 'amber') {
    bar.classList.add('amber');
    dot.classList.add('amber');
  } else if (type === 'gray') {
    bar.classList.add('gray');
    dot.classList.add('gray');
  } else {
    // loading / spinner
    bar.classList.add('loading');
    dot.classList.add('gray');
    dot.style.opacity = '0.3';
    dot.style.animation = 'pulse 1s infinite';
  }
}

const setConnStatus = (type, text) => setBarStatus(connBar, connDot, connText, type, text);
const setCodStatus  = (type, text) => setBarStatus(codBar, codDot, codText, type, text);

// ── Backend connection check (GET /api/auth/me) ────────────────────────────
async function checkConnection() {
  const origin = normalizeUrl(urlInput.value.trim()) || DEFAULT_ORIGIN;
  const token  = apiTokenInput.value.trim();

  if (!token) {
    setConnStatus('amber', AUTH_ERROR);
    return;
  }

  try {
    const res = await fetch(`${origin}/api/auth/me`, {
      headers: { Authorization: `Bearer ${token}` }
    });

    if (res.status === 200) {
      const data = await res.json().catch(() => ({}));
      const username = data.user?.username || data.username || 'user';
      setConnStatus('connected', `Connected as ${username}`);
    } else if (res.status === 401) {
      setConnStatus('amber', AUTH_ERROR);
    } else {
      setConnStatus('amber', `Unexpected response (${res.status})`);
    }
  } catch {
    setConnStatus('gray', 'Unreachable — check the backend URL');
  }
}

// ── CODINAFRICA push status ─────────────────────────────────────────────────
function checkCodinafricaStatus() {
  chrome.tabs.query({ url: '*://*.codinafrica.com/*' }, (tabs) => {
    if (tabs.length === 0) {
      setCodStatus('gray', 'CODINAFRICA not detected');
      return;
    }

    chrome.tabs.sendMessage(tabs[0].id, { type: 'SERATH_STATUS' }, (response) => {
      if (chrome.runtime.lastError) {
        setCodStatus('amber', 'CODINAFRICA open — reload the tab');
        return;
      }

      if (response && response.linked) {
        setCodStatus('connected', 'CODINAFRICA linked ✓');
      } else if (response && response.status === 401) {
        setCodStatus('amber', AUTH_ERROR);
      } else if (response && response.hasToken) {
        setCodStatus('amber', 'CODINAFRICA token ready, push pending');
      } else {
        setCodStatus('gray', 'CODINAFRICA open — log in first');
      }
    });
  });
}

// ── Load saved settings ─────────────────────────────────────────────────────
chrome.storage.local.get(['serathUrl', 'apiToken', 'authError'], (result) => {
  // Migrate old full-path URLs to origin-only
  const stored = normalizeUrl(result.serathUrl) || DEFAULT_ORIGIN;
  if (stored !== result.serathUrl) {
    chrome.storage.local.set({ serathUrl: stored });
  }
  urlInput.value = stored;
  apiTokenInput.value = result.apiToken || '';

  if (result.authError) {
    setConnStatus('amber', AUTH_ERROR);
  } else {
    checkConnection();
  }
  checkCodinafricaStatus();
});

// ── Save ────────────────────────────────────────────────────────────────────
saveBtn.addEventListener('click', () => {
  const normalized = normalizeUrl(urlInput.value.trim());
  const finalUrl = normalized || DEFAULT_ORIGIN;
  const apiToken = apiTokenInput.value.trim();

  urlInput.value = finalUrl; // show normalized value

  chrome.storage.local.set({ serathUrl: finalUrl, apiToken }, () => {
    chrome.storage.local.remove('authError');

    saveBtn.textContent = '✓ Saved!';
    saveBtn.style.color = '#10b981';
    saveBtn.style.borderColor = 'rgba(16, 185, 129, 0.4)';
    setTimeout(() => {
      saveBtn.textContent = '💾 Save';
      saveBtn.style.color = '#00f0ff';
      saveBtn.style.borderColor = 'rgba(0, 240, 255, 0.3)';
    }, 1500);

    checkConnection();
    checkCodinafricaStatus();
  });
});

// ── Test Connection ─────────────────────────────────────────────────────────
testBtn.addEventListener('click', async () => {
  testBtn.textContent = '⏳ Testing';
  testBtn.disabled = true;

  await checkConnection();

  // Flash highlight to draw attention to the result
  connBar.style.background = 'rgba(255, 255, 255, 0.05)';
  setTimeout(() => { connBar.style.background = ''; }, 600);

  testBtn.textContent = '🔌 Test';
  testBtn.disabled = false;
});

// ── Refresh (CODINAFRICA push) ──────────────────────────────────────────────
refreshBtn.addEventListener('click', () => {
  setCodStatus('loading', 'Syncing...');

  chrome.storage.local.get(['apiToken'], (result) => {
    const apiToken = (result.apiToken || '').trim();
    if (!apiToken) {
      setConnStatus('amber', AUTH_ERROR);
      setCodStatus('amber', 'No API token set');
      return;
    }

    chrome.tabs.query({ url: '*://*.codinafrica.com/*' }, (tabs) => {
      if (tabs.length === 0) {
        setCodStatus('gray', 'No CODINAFRICA tab open');
        return;
      }

      chrome.tabs.sendMessage(tabs[0].id, { type: 'SERATH_REFRESH' }, (response) => {
        if (chrome.runtime.lastError) {
          chrome.tabs.reload(tabs[0].id);
          setCodStatus('amber', 'Reloading tab...');
          return;
        }

        if (response && response.status === 401) {
          setConnStatus('amber', AUTH_ERROR);
          setCodStatus('amber', AUTH_ERROR);
        } else if (response && response.success) {
          setCodStatus('connected', 'CODINAFRICA linked ✓');
          // Re-check the backend connection now that we pushed
          checkConnection();
        } else {
          const err = (response && response.error) || 'Not logged in to CODINAFRICA';
          setCodStatus('amber', err);
        }
      });
    });
  });
});
