// Serath Sync — Background Service Worker
// Handles token push from content script. Service workers are not subject
// to mixed-content blocking, so HTTP requests work even from HTTPS pages.
// serathUrl is now stored as an ORIGIN (protocol + host + port);
// /api/settings is appended here.

const DEFAULT_ORIGIN = 'https://serathcod-app.oxp95q.easypanel.host';
const AUTH_ERROR = 'token missing/expired — paste a new one from Settings';

function getApiToken() {
  return new Promise((resolve) => {
    chrome.storage.local.get(['apiToken'], (result) => {
      resolve((result.apiToken || '').trim());
    });
  });
}

function buildSettingsUrl(origin) {
  return (origin || DEFAULT_ORIGIN).replace(/\/+$/, '') + '/api/settings';
}

async function pushSettingsToken(token, serathUrl) {
  const apiToken = await getApiToken();

  if (!apiToken) {
    await chrome.storage.local.set({ authError: AUTH_ERROR });
    return { success: false, error: AUTH_ERROR, status: 401 };
  }

  try {
    const endpoint = buildSettingsUrl(serathUrl);
    const response = await fetch(endpoint, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${apiToken}`
      },
      body: JSON.stringify({ codinafrica_token: token })
    });
    const data = await response.json().catch(() => ({}));

    if (response.status === 401) {
      await chrome.storage.local.set({ authError: AUTH_ERROR });
      return { success: false, error: AUTH_ERROR, status: 401 };
    }

    if (!response.ok || !data.success) {
      return {
        success: false,
        error: data.error || `Backend returned HTTP ${response.status}`,
        status: response.status
      };
    }

    await chrome.storage.local.remove('authError');
    return { success: true };
  } catch (err) {
    return { success: false, error: err.message };
  }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'SERATH_PUSH_TOKEN') {
    const { token, serathUrl } = message;

    pushSettingsToken(token, serathUrl).then(sendResponse);

    return true; // Keep channel open for async
  }
});
